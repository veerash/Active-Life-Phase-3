package com.android.activelife.tampa.constants;

/**
 * Created by vsatrasala on 6/29/2017.
 */

public class StaticValuesConstants {

    public static String BASE_URL="http://tampa.consoria.com/api/";
}
