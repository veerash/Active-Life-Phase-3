package com.android.activelife.tampa.adpater;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.android.activelife.tampa.R;
import com.android.activelife.tampa.db.ScheduleDateData;
import com.android.activelife.tampa.ui.MainActivity;
import com.android.activelife.tampa.ui.ReserveActivity;
import com.android.activelife.tampa.util.Utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Created by vsatrasala on 2/11/2017.
 */

public class SchedulesDateDbListAdapter extends BaseAdapter {

    public Context jContext;
    private List<ScheduleDateData> mMessagesDataResponseList;

    public SchedulesDateDbListAdapter(Context ctx, List<ScheduleDateData> mMessagesDataResponseList) {
        this.jContext = ctx;
        this.mMessagesDataResponseList=mMessagesDataResponseList;
    }

    @Override
    public int getCount() {
        return mMessagesDataResponseList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;

        if (convertView == null) {
            holder = new ViewHolder();
            convertView = LayoutInflater.from(jContext).inflate(R.layout.calender_date_list_row, parent, false);
            holder.tvYmca=(TextView)convertView.findViewById(R.id.tv_ymca);
            holder.tvHours=(TextView)convertView.findViewById(R.id.tv_hours);
            holder.tvMins=(TextView)convertView.findViewById(R.id.tv_mins);
            holder.tvName=(TextView)convertView.findViewById(R.id.tv_name);
            holder.tvEvent=(TextView)convertView.findViewById(R.id.tv_event);
            holder.reserveButton=(TextView)convertView.findViewById(R.id.reserve);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.tvYmca.setText(""+mMessagesDataResponseList.get(position).getLocation_name());
        holder.tvHours.setText(Utils.getApplyiedDateType(""+mMessagesDataResponseList.get(position).getSchedule_start_time(),"HH:mm:ss","hh:mm a"));
        DateFormat df = new SimpleDateFormat("HH:mm:ss");
        Date startDate=null, endDate=null;
        try {
             startDate=df.parse(mMessagesDataResponseList.get(position).getSchedule_start_time());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        try {
            endDate=df.parse(mMessagesDataResponseList.get(position).getSchedule_end_time());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long duration  = endDate.getTime() - startDate.getTime();

        long diffInMinutes = TimeUnit.MILLISECONDS.toMinutes(duration);
        holder.tvMins.setText(""+diffInMinutes +"Mins");
        holder.tvEvent.setText(""+mMessagesDataResponseList.get(position).getClass_name());
        holder.tvName.setText(""+mMessagesDataResponseList.get(position).getInstructor_name());
        holder.reserveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent reserveIntent = new Intent(jContext, ReserveActivity.class);
                reserveIntent.putExtra("session_id",mMessagesDataResponseList.get(position).getSchedule_id());
                ((MainActivity)jContext).startActivityForResult(reserveIntent,1000);
            }
        });
        if (mMessagesDataResponseList.get(position).getIs_reservable() == 1) {
            holder.reserveButton.setVisibility(View.VISIBLE);
        } else {
            holder.reserveButton.setVisibility(View.GONE);
        }
        return convertView;
    }

    class ViewHolder {
        TextView tvYmca,tvHours, tvMins, tvEvent, tvName, reserveButton;
    }
}
