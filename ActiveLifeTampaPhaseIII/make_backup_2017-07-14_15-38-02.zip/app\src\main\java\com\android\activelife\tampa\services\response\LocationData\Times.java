
package com.android.activelife.tampa.services.response.LocationData;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Times {

    @SerializedName("1")
    @Expose
    private List<com.android.activelife.tampa.services.response.LocationData._1> _1 = null;
    @SerializedName("2")
    @Expose
    private List<com.android.activelife.tampa.services.response.LocationData._2> _2 = null;
    @SerializedName("3")
    @Expose
    private List<com.android.activelife.tampa.services.response.LocationData._3> _3 = null;
    @SerializedName("4")
    @Expose
    private List<com.android.activelife.tampa.services.response.LocationData._4> _4 = null;
    @SerializedName("5")
    @Expose
    private List<com.android.activelife.tampa.services.response.LocationData._5> _5 = null;
    @SerializedName("6")
    @Expose
    private List<com.android.activelife.tampa.services.response.LocationData._6> _6 = null;
    @SerializedName("7")
    @Expose
    private List<com.android.activelife.tampa.services.response.LocationData._7> _7 = null;

    public List<com.android.activelife.tampa.services.response.LocationData._1> get1() {
        return _1;
    }

    public void set1(List<com.android.activelife.tampa.services.response.LocationData._1> _1) {
        this._1 = _1;
    }

    public List<com.android.activelife.tampa.services.response.LocationData._2> get2() {
        return _2;
    }

    public void set2(List<com.android.activelife.tampa.services.response.LocationData._2> _2) {
        this._2 = _2;
    }

    public List<com.android.activelife.tampa.services.response.LocationData._3> get3() {
        return _3;
    }

    public void set3(List<com.android.activelife.tampa.services.response.LocationData._3> _3) {
        this._3 = _3;
    }

    public List<com.android.activelife.tampa.services.response.LocationData._4> get4() {
        return _4;
    }

    public void set4(List<com.android.activelife.tampa.services.response.LocationData._4> _4) {
        this._4 = _4;
    }

    public List<com.android.activelife.tampa.services.response.LocationData._5> get5() {
        return _5;
    }

    public void set5(List<com.android.activelife.tampa.services.response.LocationData._5> _5) {
        this._5 = _5;
    }

    public List<com.android.activelife.tampa.services.response.LocationData._6> get6() {
        return _6;
    }

    public void set6(List<com.android.activelife.tampa.services.response.LocationData._6> _6) {
        this._6 = _6;
    }

    public List<com.android.activelife.tampa.services.response.LocationData._7> get7() {
        return _7;
    }

    public void set7(List<com.android.activelife.tampa.services.response.LocationData._7> _7) {
        this._7 = _7;
    }

}
